package com.tla.reader

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Book(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String, val category: String, val dateAdded: Long, val file: String,
    val fav: Boolean = false, val lastPage: Int = 0)

@Entity data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String, val content: String, val category: String, val dateAdded: Long,
    val fav: Boolean = false)

@Dao interface TlaDao {
    @Query("SELECT * FROM Book ORDER BY dateAdded DESC") fun books(): Flow<List<Book>>
    @Query("SELECT * FROM Note ORDER BY dateAdded DESC") fun notes(): Flow<List<Note>>
    @Upsert suspend fun up(b: Book)
    @Upsert suspend fun up(n: Note)
    @Delete suspend fun del(b: Book)
    @Delete suspend fun del(n: Note)
    @Query("UPDATE Book SET lastPage=:p WHERE id=:id") suspend fun setPage(id: Int, p: Int)
}

@Database(entities = [Book::class, Note::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): TlaDao }
