package com.tla.reader

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

val cats = listOf("School", "Mathematics", "Science", "Geography", "Technology", "Other")
val Blue = Color(0xFF1565C0)
val Green = Color(0xFF2E7D32)
fun fmt(t: Long): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(t))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val p = getSharedPreferences("tla", MODE_PRIVATE)
        val dao = Room.databaseBuilder(applicationContext, Db::class.java, "tla.db").build().dao()
        setContent { App(p, dao) }
    }
}

@Composable fun App(p: SharedPreferences, dao: TlaDao) {
    var dark by remember { mutableStateOf(p.getBoolean("dark", false)) }
    var name by remember { mutableStateOf(p.getString("name", "") ?: "") }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF90CAF9), secondary = Color(0xFFA5D6A7))
    else lightColorScheme(primary = Blue, secondary = Green)
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize()) {
            if (name.isBlank()) Welcome { n, e ->
                p.edit().putString("name", n).putString("email", e).apply(); name = n
            } else Main(p, dao, dark, { dark = it; p.edit().putBoolean("dark", it).apply() }, name) {
                name = it; p.edit().putString("name", it).apply()
            }
        }
    }
}

@Composable fun Logo(size: Int) {
    Box(Modifier.size(size.dp).background(Brush.linearGradient(listOf(Blue, Green)), CircleShape), Alignment.Center) {
        Icon(Icons.Filled.School, null, tint = Color.White, modifier = Modifier.size((size * 0.6).dp))
    }
}

@Composable fun Welcome(onDone: (String, String) -> Unit) {
    var n by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Logo(112)
        Text("TLA", fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Text("The Learning App", fontSize = 18.sp)
        Text("Read • Learn • Grow", color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(bottom = 24.dp))
        Text("Welcome! What should we call you?", fontSize = 18.sp)
        OutlinedTextField(n, { n = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
        OutlinedTextField(e, { e = it }, label = { Text("Email (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
        Button({ onDone(n.trim(), e.trim()) }, enabled = n.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Get Started") }
        Text("Free. Works offline. Data stays on your phone.", fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable fun CatPicker(cur: String, onPick: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(cats) { c -> FilterChip(selected = c == cur, onClick = { onPick(c) }, label = { Text(c) }) }
    }
}

@Composable fun SearchBox(q: String, onQ: (String) -> Unit) {
    OutlinedTextField(q, onQ, placeholder = { Text("Search books & notes") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
        singleLine = true, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth())
}

@Composable fun FavIcon(fav: Boolean, onClick: () -> Unit) {
    IconButton(onClick) {
        Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorite",
            tint = if (fav) Color.Red else LocalContentColor.current)
    }
}

@Composable fun BookRow(b: Book, open: () -> Unit, fav: () -> Unit, del: () -> Unit) {
    Card(onClick = open, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.MenuBook, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(b.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${b.category} • ${fmt(b.dateAdded)}" + if (b.lastPage > 0) " • page ${b.lastPage + 1}" else "", fontSize = 13.sp)
            }
            FavIcon(b.fav, fav)
            IconButton(del) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}

@Composable fun NoteRow(n: Note, open: () -> Unit, fav: () -> Unit, del: () -> Unit) {
    Card(onClick = open, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.EditNote, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(36.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(n.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(n.content, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${n.category} • ${fmt(n.dateAdded)}", fontSize = 12.sp)
            }
            FavIcon(n.fav, fav)
            IconButton(del) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }
}

@Composable fun Main(p: SharedPreferences, dao: TlaDao, dark: Boolean, setDark: (Boolean) -> Unit, name: String, onName: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val books by dao.books().collectAsState(emptyList())
    val notes by dao.notes().collectAsState(emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var reading by remember { mutableStateOf<Book?>(null) }
    var editing by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<Note?>(null) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { pending = it }

    if (reading != null) { Reader(reading!!, dao) { reading = null }; return }
    if (editing) { Editor(note, dao) { editing = false }; return }

    pending?.let { u ->
        val def = remember(u) {
            (ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
            } ?: "Book").removeSuffix(".pdf")
        }
        var t by remember(u) { mutableStateOf(def) }
        var cat by remember(u) { mutableStateOf("School") }
        AlertDialog(onDismissRequest = { pending = null }, title = { Text("Add Book") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(t, { t = it }, label = { Text("Title") })
                    CatPicker(cat) { cat = it }
                }
            },
            confirmButton = {
                TextButton({
                    pending = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            val f = "${System.currentTimeMillis()}.pdf"
                            ctx.contentResolver.openInputStream(u)?.use { i -> File(ctx.filesDir, f).outputStream().use { i.copyTo(it) } }
                            dao.up(Book(title = t.ifBlank { "Untitled" }, category = cat, dateAdded = System.currentTimeMillis(), file = f))
                        }
                    }
                }) { Text("Import") }
            },
            dismissButton = { TextButton({ pending = null }) { Text("Cancel") } })
    }

    val fb = books.filter { q.isBlank() || it.title.contains(q, true) || it.category.contains(q, true) }
    val fn = notes.filter { q.isBlank() || it.title.contains(q, true) || it.content.contains(q, true) || it.category.contains(q, true) }
    val addBook = { picker.launch(arrayOf("application/pdf")) }
    val newNote = { note = null; editing = true }

    fun LazyListScope.bs(t: String, l: List<Book>) {
        item { Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (l.isEmpty()) item { Text("Nothing here yet") }
        else items(l) { b ->
            BookRow(b, { reading = b }, { scope.launch { dao.up(b.copy(fav = !b.fav)) } },
                { scope.launch { dao.del(b); File(ctx.filesDir, b.file).delete() } })
        }
    }
    fun LazyListScope.ns(t: String, l: List<Note>) {
        item { Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (l.isEmpty()) item { Text("Nothing here yet") }
        else items(l) { n ->
            NoteRow(n, { note = n; editing = true }, { scope.launch { dao.up(n.copy(fav = !n.fav)) } }, { scope.launch { dao.del(n) } })
        }
    }

    val tabs = listOf("Home" to Icons.Filled.Home, "Books" to Icons.Filled.MenuBook, "Field Notes" to Icons.Filled.EditNote,
        "Favorites" to Icons.Filled.Favorite, "Settings" to Icons.Filled.Settings)
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (l, ic) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l, fontSize = 10.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tab) {
                0 -> {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Logo(56)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text("Welcome, $name", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("Read • Learn • Grow", color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                    item { SearchBox(q) { q = it } }
                    item {
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                            Button({ addBook() }, Modifier.weight(1f)) { Text("Add Book") }
                            Button({ newNote() }, Modifier.weight(1f)) { Text("Add Field Note") }
                        }
                    }
                    if (q.isBlank()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Categories", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                CatPicker("") { q = it }
                            }
                        }
                        bs("Continue Reading", books.filter { it.lastPage > 0 }.take(3))
                        bs("Recently Added", books.take(4))
                        bs("Favorites", books.filter { it.fav }.take(3))
                        ns("Field Notes", notes.take(3))
                    } else { bs("Books", fb); ns("Field Notes", fn) }
                }
                1 -> {
                    item { SearchBox(q) { q = it } }
                    item { Button({ addBook() }, Modifier.fillMaxWidth()) { Text("Import PDF Book") } }
                    bs("Library", fb)
                }
                2 -> {
                    item { SearchBox(q) { q = it } }
                    item { Button({ newNote() }, Modifier.fillMaxWidth()) { Text("New Field Note") } }
                    ns("Field Notes", fn)
                }
                3 -> {
                    bs("Favorite Books", books.filter { it.fav })
                    ns("Favorite Field Notes", notes.filter { it.fav })
                }
                else -> item {
                    val mb = (ctx.filesDir.listFiles()?.sumOf { it.length() } ?: 0L) / 1048576.0
                    SettingsPane(p, dark, setDark, name, onName, mb)
                }
            }
        }
    }
}

@Composable fun SettingsPane(p: SharedPreferences, dark: Boolean, setDark: (Boolean) -> Unit, name: String, onName: (String) -> Unit, mb: Double) {
    var info by remember { mutableStateOf<Pair<String, String>?>(null) }
    var edit by remember { mutableStateOf(false) }
    val rows = listOf(
        "Cloud Sync" to "Not configured. Cloud sync (Firebase/Supabase) is not active, so nothing leaves your device. TLA works fully offline.",
        "About TLA" to "TLA (The Learning App) is a free educational reading app. Read • Learn • Grow.",
        "Privacy Policy" to "TLA stores your profile, books, notes and progress only on this device. No permissions, analytics or accounts are used.",
        "Terms of Use" to "TLA is provided free, as is. Only import documents you have the right to read.",
        "Help" to "Books tab: import PDFs, tap to read. Field Notes tab: write notes. Tap the heart to favorite. Use search to find anything.")
    Column {
        ListItem(headlineContent = { Text("Profile") }, supportingContent = { Text(name + (p.getString("email", "")?.let { if (it.isBlank()) "" else " • $it" } ?: "")) },
            modifier = Modifier.clickable { edit = true })
        ListItem(headlineContent = { Text("Dark Mode") }, trailingContent = { Switch(dark, setDark) })
        ListItem(headlineContent = { Text("Storage") }, supportingContent = { Text("%.1f MB used by imported books".format(mb)) })
        rows.forEach { (t, m) -> ListItem(headlineContent = { Text(t) }, modifier = Modifier.clickable { info = t to m }) }
        ListItem(headlineContent = { Text("App Version") }, supportingContent = { Text("1.0") })
    }
    info?.let { (t, m) ->
        AlertDialog(onDismissRequest = { info = null }, title = { Text(t) }, text = { Text(m) }, confirmButton = { TextButton({ info = null }) { Text("OK") } })
    }
    if (edit) {
        var n by remember { mutableStateOf(name) }
        AlertDialog(onDismissRequest = { edit = false }, title = { Text("Your name") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true) },
            confirmButton = { TextButton({ if (n.isNotBlank()) onName(n.trim()); edit = false }) { Text("Save") } })
    }
}

@Composable fun Editor(n: Note?, dao: TlaDao, done: () -> Unit) {
    val scope = rememberCoroutineScope()
    var t by remember { mutableStateOf(n?.title ?: "") }
    var c by remember { mutableStateOf(n?.content ?: "") }
    var cat by remember { mutableStateOf(n?.category ?: "School") }
    BackHandler(onBack = done)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(done) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text(if (n == null) "New Field Note" else "Edit Field Note", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(t, { t = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        CatPicker(cat) { cat = it }
        OutlinedTextField(c, { c = it }, label = { Text("Content") }, modifier = Modifier.fillMaxWidth().weight(1f))
        Button({
            if (t.isNotBlank()) scope.launch {
                dao.up((n ?: Note(title = "", content = "", category = "", dateAdded = System.currentTimeMillis())).copy(title = t.trim(), content = c, category = cat))
                done()
            }
        }, Modifier.fillMaxWidth()) { Text("Save") }
    }
}

@Composable fun Reader(b: Book, dao: TlaDao, back: () -> Unit) {
    val ctx = LocalContext.current
    val r = remember { runCatching { PdfRenderer(ParcelFileDescriptor.open(File(ctx.filesDir, b.file), ParcelFileDescriptor.MODE_READ_ONLY)) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { r?.let { synchronized(it) { it.close() } } } }
    val total = r?.pageCount ?: 0
    var page by remember { mutableIntStateOf(b.lastPage.coerceIn(0, maxOf(0, total - 1))) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    val sc = rememberScrollState()
    BackHandler(onBack = back)
    LaunchedEffect(page) {
        if (r != null && total > 0) {
            bmp = withContext(Dispatchers.IO) {
                synchronized(r) {
                    r.openPage(page).use { pg ->
                        val w = 1080; val h = w * pg.height / pg.width
                        Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.eraseColor(android.graphics.Color.WHITE); pg.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) }
                    }
                }
            }
            sc.scrollTo(0)
            dao.setPage(b.id, page)
        }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text(b.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(sc)) {
            val m = bmp
            if (r == null) Text("Could not open this PDF.", Modifier.padding(16.dp))
            else if (m != null) Image(m.asImageBitmap(), "Page ${page + 1}", Modifier.fillMaxWidth())
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            IconButton({ page-- }, enabled = page > 0) { Icon(Icons.Filled.ArrowBack, "Previous page") }
            Text("${if (total == 0) 0 else page + 1} / $total", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            IconButton({ page++ }, enabled = page < total - 1) { Icon(Icons.Filled.ArrowForward, "Next page") }
        }
    }
}
